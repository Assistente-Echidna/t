const regurus = (prefix) => {
	return `
	
	「꧁꧅ᏒꂅguᏒuᏕ꧅꧂」 
                      「B⃟O⃟T⃟*」


༻══ •『𝐈 𝐌 𝐏 𝐎 𝐑 𝐓 𝐀 𝐍 𝐓 𝐄 』• ══༺
➪𝑩𝑶𝑻 𝑻𝑹𝑨𝑫𝑼𝒁𝑰𝑫𝑶 𝑷𝑶𝑹 :
@k1r1t0_edits & @otaku.exp
➪𝑴𝑬𝑼 𝒀𝑶𝑼𝑻𝑼𝑩𝑬 :
https://youtube.com/channel/UCz0zX7CX5V4RsFKB8lncYRQ
➪𝑩𝑶𝑻 𝑪𝑹𝑰𝑨𝑫𝑶 𝑷𝑨𝑹𝑨 𝑬𝑵𝑻𝑹𝑬𝑻𝑬𝑵𝑰𝑴𝑬𝑵𝑻𝑶 .
➪PARA ADICIONAR O BOT EM UM GRUPO, MANDE UMA MENSAGEM NO NÚMERO ABAIXO:
wa.me/+5544999862424

༻══ •『𝑪 𝑶 𝑴 𝑨 𝑵 𝑫 𝑶 𝑺 』• ══༺


◆ ▬▬▬▬▬ ❴𝕾 𝕺 𝕭 𝕽 𝕰 ❵▬▬▬▬▬◆

*╔═══✤ •ೋ°۝°ೋ•✤ ═══╗*
> ${prefix}
> ${prefix}
> ${prefix}
*╚═══✤ •ೋ°۝°ೋ•✤ ═══╝*

◆ ▬▬▬▬▬ ❴𝕮 𝕽 𝕴 𝕬 𝕽❵▬▬▬▬▬◆

*╔═══✤ •ೋ°۝°ೋ•✤ ═══╗*
> ${prefix}sticker
> ${prefix}stickergif
> ${prefix}toimg
*╚═══✤ •ೋ°۝°ೋ•✤ ═══╝*

◆ ▬▬▬▬▬ ❴𝕸 𝕴 𝕯 𝕴 𝕬 ❵▬▬▬▬▬◆

*╔═══✤ •ೋ°۝°ೋ•✤ ═══╗*
> ${prefix}
> ${prefix}
> ${prefix}
*╚═══✤ •ೋ°۝°ೋ•✤ ═══╝*

◆ ▬▬▬▬▬ ❴𝕭 𝕬 𝕴 𝖃 𝕬 𝕽 ❵▬▬▬▬▬◆

*╔═══✤ •ೋ°۝°ೋ•✤ ═══╗*
> ${prefix}
> ${prefix}
> ${prefix}
*╚═══✤ •ೋ°۝°ೋ•✤ ═══╝*

◆ ▬▬▬▬▬ ❴𝕸 𝖀 𝕾 𝕴 𝕮 𝕬 ❵▬▬▬▬▬◆

*╔═══✤ •ೋ°۝°ೋ•✤ ═══╗*
> ${prefix}play
> ${prefix}tts
*╚═══✤ •ೋ°۝°ೋ•✤ ═══╝*

◆ ▬▬▬▬▬ ❴𝕺 𝕿 𝕬 𝕶 𝖀 ❵▬▬▬▬▬◆

*╔═══✤ •ೋ°۝°ೋ•✤ ═══╗*
> ${prefix}loli
> ${prefix}randomanime
> ${prefix}nekoanime
*╚═══✤ •ೋ°۝°ೋ•✤ ═══╝*

◆ ▬▬▬▬▬ ❴𝕴 𝕹 𝕱 𝕺 ❵▬▬▬▬▬◆

*╔═══✤ •ೋ°۝°ೋ•✤ ═══╗*
> ${prefix}
> ${prefix}
> ${prefix}
*╚═══✤ •ೋ°۝°ೋ•✤ ═══╝*

◆ ▬▬▬▬▬ ❴𝕯 𝕺 𝕹 𝕺 ❵▬▬▬▬▬◆

*╔═══✤ •ೋ°۝°ೋ•✤ ═══╗*
> ${prefix}
> ${prefix}
> ${prefix}
*╚═══✤ •ೋ°۝°ೋ•✤ ═══╝*
`
}

exports.regurus = regurus
