const help = (prefix, ownerBot, botName) => {
        return `
「 *${botName}* 」

◪ *INFO*
  ❏ Prefix: 「  ${prefix}  」
  ❏ Creator: ${ownerBot}
✤   ✓  𝗠 𝗘 𝗡 𝗨-𝗧 𝗥 𝗔 𝗩 𝗔 𝗦  ✓ ✤ 
  │
  ├─  ☛${prefix}
  ├─  ☛${prefix}
  ├─  ☛${prefix}
  ├─  ☛${prefix} 
  ├─  ☛${prefix}
  ├─  ☛${prefix}
  ├─  ☛${prefix}
}
exports.help = help
